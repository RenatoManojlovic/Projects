package aplikacija;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color; 



public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField kime;
	private JPasswordField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 498, 345);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(253, 234, 219));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOGIN");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel.setBounds(189, 24, 158, 46);
		contentPane.add(lblNewLabel);
		
		JLabel lbNewlabel = new JLabel("Korisničko ime:");
		lbNewlabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lbNewlabel.setBounds(37, 102, 111, 22);
		contentPane.add(lbNewlabel);
		
		kime = new JTextField();
		kime.setBounds(141, 105, 227, 20);
		contentPane.add(kime);
		kime.setColumns(10);
		
		JLabel lbNewlabel_1 = new JLabel("Lozinka: ");
		lbNewlabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lbNewlabel_1.setBounds(77, 154, 92, 22);
		contentPane.add(lbNewlabel_1);
		
		JButton potvrdi = new JButton("Potvrdi");
		potvrdi.setFont(new Font("Tahoma", Font.BOLD, 15));
		potvrdi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			 
			    String kimes, passs;
			    kimes= kime.getText();
			    passs = String.valueOf(pass.getPassword());
			    try
				 {

				 Class.forName("com.mysql.cj.jdbc.Driver");
                 Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/rmanojlovic?serverTimezone=UTC", "rmanojlovic", "11");

				 String upit="SELECT Korisnicko_ime FROM Korisnik WHERE Korisnicko_ime=? and Lozinka=?";
				 String lozinka = new String (passs);
				 PreparedStatement ps=con.prepareStatement(upit);
				 ps.setString(1, kimes);
				 ps.setString(2, lozinka);
				 ResultSet rs=ps.executeQuery();
				 Statement stmt=con.createStatement();
				 if (rs.next())
				 {
					 
				 JOptionPane.showMessageDialog(null, "Logirani ste");
				 Prozor1 prozor=new Prozor1();
				 prozor.setVisible(true);
				 dispose();
				 }
				 else
				 JOptionPane.showMessageDialog(null, "Pogrešno upisani podatci");

				 }
				 catch(Exception e1)
				 {
				 JOptionPane.showMessageDialog(null, e1);
				 } 

			
			
			
			} 
		
		});
		potvrdi.setBounds(279, 229, 137, 41);
		contentPane.add(potvrdi);
		
		pass = new JPasswordField();
		pass.setBounds(141, 157, 227, 20);
		contentPane.add(pass);
	}
}
