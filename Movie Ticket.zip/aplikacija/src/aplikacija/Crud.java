package aplikacija;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.sql.*;

import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Year;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Crud extends JFrame {
	private JPanel contentPane;
	private JTextField ime;
	private JTextField cijena;
	private JTextField dvorana;
	private JTextField datum;
	private JTextField vrijeme;
	private JTable tablica;
	DefaultTableModel model;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Crud frame = new Crud();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Crud() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 664, 462);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(253, 234, 219));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("ADMIN ");
		lblNewLabel.setBackground(new Color(255, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(298, 11, 184, 28);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Ime filma:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(10, 61, 61, 14);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("Cijena:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_3.setBounds(10, 102, 46, 14);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Dvorana: ");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_4.setBounds(10, 144, 72, 14);
		getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Datum:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_5.setBounds(10, 186, 46, 14);
		getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Vrijeme:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_6.setBounds(10, 223, 61, 14);
		getContentPane().add(lblNewLabel_6);
		
		ime = new JTextField();
		ime.setBounds(70, 58, 117, 20);
		getContentPane().add(ime);
		ime.setColumns(10);
		
		cijena = new JTextField();
		cijena.setBounds(69, 99, 118, 20);
		getContentPane().add(cijena);
		cijena.setColumns(10);
		
		dvorana = new JTextField();
		dvorana.setBounds(70, 141, 117, 20);
		getContentPane().add(dvorana);
		dvorana.setColumns(10);
		
		datum = new JTextField();
		datum.setBounds(70, 183, 117, 20);
		getContentPane().add(datum);
		datum.setColumns(10);
		
		vrijeme = new JTextField();
		vrijeme.setBounds(70, 220, 117, 20);
		getContentPane().add(vrijeme);
		vrijeme.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(221, 50, 427, 362);
		getContentPane().add(scrollPane);
		
		tablica = new JTable();
		scrollPane.setViewportView(tablica);
		model=new DefaultTableModel();
		Object[] column= {"Ime", "Cijena", "Dvorana", "Datum", "Vrijeme"};
		Object[] row= new Object[5];
	    model.setColumnIdentifiers(column);
		tablica.setModel(model);
		tablica.setDefaultEditor(Object.class, null);
		
		JButton create = new JButton("CREATE");
		create.setFont(new Font("Tahoma", Font.BOLD, 13));
		create.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 
				
				try
				 {

				 Class.forName("com.mysql.cj.jdbc.Driver");
                 Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/rmanojlovic?serverTimezone=UTC", "rmanojlovic", "11");

				if (ime.getText().equals("") ||cijena.getText().equals("") || dvorana.getText().equals("") || datum.getText().equals("") || vrijeme.getText().equals(""))
				{
					JOptionPane.showMessageDialog(null, "Popunite sva polja!");
				}
				
				else
				{
					
					String upit1="INSERT INTO Filmovi (Ime,Cijena, Dvorana, Datum, Vrijeme) VALUES (?,?, ?, ?, ? )";
					PreparedStatement
					ps1=con.prepareStatement(upit1);
					row[0]=ime.getText();
					
					row[1]=cijena.getText();
					row[2]=dvorana.getText();
					row[3]=datum.getText();
					row[4]=vrijeme.getText();
					model.addRow(row);
					
					 ps1.setString(1, (String) row[0]);

					

					 ps1.setString(2, (String) row[1]);

					 ps1.setString(3, (String) row[2]);

					 ps1.setString(4, (String) row[3]);

					 ps1.setString(5, (String) row[4]);
					 ps1.execute();

					
					ime.setText("");
					
					cijena.setText("");
					dvorana.setText("");
					datum.setText("");
					vrijeme.setText("");
				}	
				}
				 catch(Exception e1)
				 {
				 JOptionPane.showMessageDialog(null, e1);
				 } 

				 	 	
			}
			
		});
		create.setBounds(10, 275, 89, 36);
		getContentPane().add(create);
		
		JButton update = new JButton("UPDATE");
		update.setFont(new Font("Tahoma", Font.BOLD, 13));
		update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 
				
				
				
				try
				 {

				 Class.forName("com.mysql.cj.jdbc.Driver");
                 Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/rmanojlovic?serverTimezone=UTC", "rmanojlovic", "11");

				int i=tablica.getSelectedRow();
				if (i>=0)
				{
					if (ime.getText().equals("") || cijena.getText().equals("") || dvorana.getText().equals("") || datum.getText().equals("") || vrijeme.getText().equals(""))
					{
						ime.setText((String) model.getValueAt(i, 0));
						
						cijena.setText((String) model.getValueAt(i, 1));
						dvorana.setText((String) model.getValueAt(i, 2));
						datum.setText((String) model.getValueAt(i, 3));
						vrijeme.setText((String) model.getValueAt(i, 4));
					}
					
					else
					
						{
						
						model.setValueAt(ime.getText(), i, 0);
						
						model.setValueAt(cijena.getText(), i, 1);
						model.setValueAt(dvorana.getText(), i, 2);
						model.setValueAt(datum.getText(), i, 3);
						model.setValueAt(vrijeme.getText(), i, 4);
						
						
						
						String imes= ime.getText();
						
						String cijenas= cijena.getText();
						String dvoranas= dvorana.getText();
						String datums= datum.getText();
						String vrijemes= vrijeme.getText();
						String upit2 = "UPDATE Filmovi SET Ime=?,Cijena=?,Dvorana=?,Datum=?,Vrijeme=? WHERE Ime=?";
						PreparedStatement ps2= con.prepareStatement(upit2);
						ps2.setString(1, imes);
						
						ps2.setString(2, cijenas);
						ps2.setString(3, dvoranas);
						ps2.setString(4, datums);
						ps2.setString(5, vrijemes);
						ps2.setString(6, imes);
						ps2.execute();
						
						
						
						
						ime.setText("");
						
						cijena.setText("");
						dvorana.setText("");
						datum.setText("");
						vrijeme.setText("");
						
						
					}
										
									
					
					
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Redak nije oznacen. Oznacite redak!");
				}
				 
			}
				 catch(Exception e3)
				 {
				 JOptionPane.showMessageDialog(null, e3);
				 } 
				  
			}
		});
		update.setBounds(126, 275, 89, 36);
		getContentPane().add(update);
		
		JButton delete = new JButton("DELETE");
		delete.setFont(new Font("Tahoma", Font.BOLD, 13));
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
            
				try
				{
				
				Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/rmanojlovic?serverTimezone=UTC", "rmanojlovic", "11");
                
             
				int i=tablica.getSelectedRow();
				
				if (i>=0)
				{
					
				
					String upit3= "DELETE FROM Filmovi WHERE Ime='"+tablica.getValueAt(tablica.getSelectedRow(), 0)+"'";
					PreparedStatement ps3= con.prepareStatement(upit3);
					
					ps3.executeUpdate();
					
					model.removeRow(i);
					JOptionPane.showMessageDialog(null, "Redak obrisan!");
					
					
					
				}
				
				else
				{
					JOptionPane.showMessageDialog(null, "Oznacite redak!");
				}
				}
				catch(Exception e4)
				{
					JOptionPane.showMessageDialog(null, e4);
				}
				}
			
			
		});
		delete.setBounds(10, 343, 89, 39);
		getContentPane().add(delete);
		
		JButton select = new JButton("SELECT");
		select.setFont(new Font("Tahoma", Font.BOLD, 13));
		select.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 
				
				try
				 {
				 Class.forName("com.mysql.cj.jdbc.Driver");
				 Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr:/rmanojlovic?serverTimezone=UTC", "rmanojlovic", "11");
				

				 Statement stmt=con.createStatement();
				 String upit="SELECT * from Filmovi";

				 ResultSet rs=stmt.executeQuery(upit);
				 DefaultTableModel model = (DefaultTableModel)tablica.getModel();
                 String imes,cijenas,dvoranas,datums,vrijemes;
				 while(rs.next())
				 {

				 imes=rs.getString(1);
				
                 cijenas=rs.getString(2);
				 dvoranas=rs.getString(3);
				 datums=rs.getString(4);
				 vrijemes=rs.getString(5);
				 String [] row = {imes,cijenas,dvoranas,datums,vrijemes };
				 model.addRow(row);

				 }


				 }

				 catch (Exception e2)
				 {
				 System.out.println(e2);
				 }



			   }
		
				
			
        });
		select.setBounds(126, 343, 89, 39);
		getContentPane().add(select);
	}
	}

	
	