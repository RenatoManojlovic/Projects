package aplikacija;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.cj.xdevapi.Statement;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class Registracija extends JFrame {
	private JTextField kime;
	private JTextField ime;
	private JTextField prezime;
	private JTextField email;
	private JTextField broj;
	private JPasswordField pass;
	private JPasswordField pass1;
	
	
		
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registracija frame = new Registracija();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			
			
			
			
			
			}
			
			
		});
	}

	/**
	 * Create the frame.
	 */
	public Registracija() {
		getContentPane().setBackground(new Color(253, 234, 219));
		setBackground(new Color(112, 217, 235));
		setFont(new Font("Arial", Font.BOLD, 18));
		setTitle("Registracija");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 569);
		getContentPane().setLayout(null);
		
		JLabel JLabel = new JLabel("Korisničko ime");
		JLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		JLabel.setBounds(32, 25, 148, 20);
		getContentPane().add(JLabel);
		
		kime = new JTextField();
		kime.setBounds(26, 58, 208, 20);
		getContentPane().add(kime);
		kime.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Ime");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setBounds(32, 97, 46, 14);
		getContentPane().add(lblNewLabel);
		
		ime = new JTextField();
		ime.setBounds(26, 122, 208, 20);
		getContentPane().add(ime);
		ime.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Prezime");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(32, 165, 121, 14);
		getContentPane().add(lblNewLabel_1);
		
		prezime = new JTextField();
		prezime.setBounds(26, 190, 208, 20);
		getContentPane().add(prezime);
		prezime.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("E-mail");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2.setBounds(32, 236, 46, 14);
		getContentPane().add(lblNewLabel_2);
		
		email = new JTextField();
		email.setBounds(26, 261, 208, 20);
		getContentPane().add(email);
		email.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Broj telefona");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_3.setBounds(32, 299, 80, 20);
		getContentPane().add(lblNewLabel_3);
		
		broj = new JTextField();
		broj.setBounds(26, 330, 208, 20);
		getContentPane().add(broj);
		broj.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Lozinka");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_4.setBounds(32, 372, 46, 14);
		getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Ponovi Lozinku");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_5.setBounds(32, 439, 148, 14);
		getContentPane().add(lblNewLabel_5);
		
		JButton potvrdis = new JButton("Potvrdi");
		potvrdis.setFont(new Font("Tahoma", Font.BOLD, 15));
		potvrdis.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String kimes,imes,prezimes,emails,brojs,passs,passs1;
				kimes = kime.getText();
				imes = ime.getText();
				prezimes= prezime.getText();
				emails = email.getText();
				brojs = broj.getText();
				passs = String.valueOf(pass.getPassword());
				passs1 = String.valueOf(pass1.getPassword());
				try
				 {

				 Class.forName("com.mysql.cj.jdbc.Driver");
                 Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/rmanojlovic?serverTimezone=UTC", "rmanojlovic", "11");

				 String upit="SELECT Korisnicko_ime FROM Korisnik WHERE Korisnicko_ime=?";
				 PreparedStatement ps=con.prepareStatement(upit);
				 ps.setString(1,kimes);
				 ResultSet rs=ps.executeQuery();
				
				  if (rs.next())
				  {

				  JOptionPane.showMessageDialog(null,"Korisnicko ime vec postoji");
				  }
				  else


				  {
				  String lozinka=new String(passs);
				  String lozinka1=new String(passs1);
				  if
				  (!lozinka.equals(lozinka1))

				  JOptionPane.showMessageDialog(null,"Lozinke nisu jednake. Molim ponovni upis");
				  else
				  {
				  if
				  ((imes.isEmpty()) || (prezimes.isEmpty()) || (kimes.isEmpty()) || (emails.isEmpty()) || (brojs.isEmpty()) )
				 

				  JOptionPane.showMessageDialog(null,"Neko polje je prazno");

				  else
				  {
				  String upit1="INSERT INTO Korisnik (Korisnicko_ime,Ime,Prezime, Broj_mob, Mail, Lozinka) VALUES (?,?, ?, ?, ?, ?)";

				 PreparedStatement
				 ps1=con.prepareStatement(upit1);

				 ps1.setString(1, kimes);

				 ps1.setString(2, imes);

				 ps1.setString(3, prezimes);

				 ps1.setString(4, brojs);

				 ps1.setString(5, emails);

				 ps1.setString(6, lozinka);

				

				
				 ps1.execute();
				 JOptionPane.showMessageDialog(null,"Uspjesno ste registrirani!");
				 Login log = new Login();
				 log.setVisible(true);
				 dispose();


				  }

				  }

				  }


				  }
				  catch(Exception e1)
				  {

				  JOptionPane.showMessageDialog(null,e1);
				  }
			
			}
		});
		potvrdis.setBounds(260, 478, 137, 41);
		getContentPane().add(potvrdis);
		
		pass = new JPasswordField();
		pass.setBounds(26, 393, 208, 20);
		getContentPane().add(pass);
		
		pass1 = new JPasswordField();
		pass1.setBounds(26, 461, 208, 20);
		getContentPane().add(pass1);
		
	}
}
