package aplikacija;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

import java.awt.Label;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class ZvarsniProzor extends JFrame {

	private JPanel contentPane;
	JLabel bsj;
	JLabel rd;
	JLabel par;
	JLabel fm;
	JLabel dvo;
	JLabel datu;
	JLabel vr;
	private JTextField vlasnik;
	private JTextField kartica;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ZvarsniProzor frame = new ZvarsniProzor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ZvarsniProzor() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 641, 452);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(253, 234, 219));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Podaci o kupnji");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(50, 37, 164, 22);
		contentPane.add(lblNewLabel);
		
		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(311, 11, 1, 391);
		contentPane.add(separator);
		
		JLabel lblNewLabel_1 = new JLabel("Kartično plaćanje");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(398, 33, 155, 31);
		contentPane.add(lblNewLabel_1);
		
	    bsj = new JLabel("New label");
		bsj.setBounds(50, 90, 24, 14);
		contentPane.add(bsj);
		
		JLabel lblNewLabel_2 = new JLabel("Broj:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2.setBounds(10, 85, 46, 22);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Red:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_3.setBounds(84, 90, 35, 14);
		contentPane.add(lblNewLabel_3);
		
		rd = new JLabel("New label");
		rd.setBounds(122, 90, 24, 14);
		contentPane.add(rd);
		
		JLabel lblNewLabel_4 = new JLabel("Parter:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_4.setBounds(156, 90, 63, 14);
		contentPane.add(lblNewLabel_4);
		
		par = new JLabel("New label");
		par.setBounds(206, 90, 46, 14);
		contentPane.add(par);
		
		JLabel lblNewLabel_5 = new JLabel("Film:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_5.setBounds(10, 132, 46, 22);
		contentPane.add(lblNewLabel_5);
		
		fm = new JLabel("New label");
		fm.setBounds(50, 136, 217, 17);
		contentPane.add(fm);
		
		JLabel lblNewLabel_6 = new JLabel("Dvorana:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_6.setBounds(10, 176, 64, 14);
		contentPane.add(lblNewLabel_6);
		
		dvo = new JLabel("New label");
		dvo.setBounds(72, 177, 46, 14);
		contentPane.add(dvo);
		
		JLabel dat = new JLabel("Datum:");
		dat.setFont(new Font("Tahoma", Font.PLAIN, 13));
		dat.setBounds(10, 223, 64, 14);
		contentPane.add(dat);
		
		JLabel vri = new JLabel("Vrijeme:");
		vri.setFont(new Font("Tahoma", Font.PLAIN, 13));
		vri.setBounds(10, 271, 64, 14);
		contentPane.add(vri);
		
		datu = new JLabel("New label");
		datu.setBounds(60, 224, 99, 14);
		contentPane.add(datu);
		
		vr = new JLabel("New label");
		vr.setBounds(73, 272, 86, 14);
		contentPane.add(vr);
		
		JLabel lblNewLabel_7 = new JLabel("Vlasnik kartice");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_7.setBounds(347, 90, 155, 22);
		contentPane.add(lblNewLabel_7);
		
		vlasnik = new JTextField();
		vlasnik.setBounds(346, 123, 207, 31);
		contentPane.add(vlasnik);
		vlasnik.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Broj kartice");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_8.setBounds(347, 204, 120, 22);
		contentPane.add(lblNewLabel_8);
		
		kartica = new JTextField();
		kartica.setBounds(347, 237, 206, 31);
		contentPane.add(kartica);
		kartica.setColumns(10);
		
		JButton btnNewButton = new JButton("Potvrdi");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String vlasniks= vlasnik.getText();
				String karticas= kartica.getText();
				
				
				try
				 {

				 Class.forName("com.mysql.cj.jdbc.Driver");
               Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/rmanojlovic?serverTimezone=UTC", "rmanojlovic", "11");
				
              
					  
				
					
					if(vlasnik.getText().equals("") || kartica.getText().equals(""))
                      {
                    	  JOptionPane.showMessageDialog(null, "Upišite podatke!");
                      }
                     
                      else
                      {
                    String upit1="INSERT INTO Kartica (Vlasnik,Broj) VALUES (?,?)";
      				PreparedStatement
      				ps1=con.prepareStatement(upit1);
      			
      				
      				 ps1.setString(1,vlasniks);

      				

      				 ps1.setString(2, karticas);
      				 ps1.execute();

                    	  
                    	  
                    JOptionPane.showMessageDialog(null, "Ulaznice kupljene!");
					dispose();
                      }
				 }

					      catch(Exception e1)
							 {
							 JOptionPane.showMessageDialog(null, e1);
							 } 
								
		                   

				          

				
				 
				 
				 }
				 
			
			
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(471, 331, 114, 43);
		contentPane.add(btnNewButton);
	}
}
