package aplikacija;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class AdminLogin extends JFrame {

	private JPanel contentPane;
	private JTextField admin;
	private JPasswordField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin frame = new AdminLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminLogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(253, 234, 219));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Admin Login");
		lblNewLabel.setBackground(new Color(255, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel.setBounds(155, 34, 150, 27);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Admin: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(72, 93, 74, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Lozinka:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(72, 163, 89, 14);
		contentPane.add(lblNewLabel_2);
		
		admin = new JTextField();
		admin.setBounds(131, 92, 202, 20);
		contentPane.add(admin);
		admin.setColumns(10);
		
		pass = new JPasswordField();
		pass.setBounds(131, 162, 202, 20);
		contentPane.add(pass);
		
		JButton btnNewButton = new JButton("Potvrdi");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String admins, passs;
				    admins= admin.getText();
				    passs = String.valueOf(pass.getPassword());
				    try
					 {

					 Class.forName("com.mysql.cj.jdbc.Driver");
	                 Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/rmanojlovic?serverTimezone=UTC", "rmanojlovic", "11");

					 String upit="SELECT Ime FROM ADMIN WHERE Ime=? and Lozinka=?";
					 String lozinka = new String (passs);
					 PreparedStatement ps=con.prepareStatement(upit);
					 ps.setString(1, admins);
					 ps.setString(2, lozinka);
					 ResultSet rs=ps.executeQuery();
					 Statement stmt=con.createStatement();
					 if (rs.next())
					 {
						 
					 JOptionPane.showMessageDialog(null, "Logirani ste");
					 Crud cru= new Crud();
					 cru.setVisible(true);
					 }
					 else
					 JOptionPane.showMessageDialog(null, "Pogrešno upisani podatci");

					 }
					 catch(Exception e1)
					 {
					 JOptionPane.showMessageDialog(null, e1);
					 } 

			}
		});
		btnNewButton.setBounds(167, 201, 113, 33);
		contentPane.add(btnNewButton);
	}
}
