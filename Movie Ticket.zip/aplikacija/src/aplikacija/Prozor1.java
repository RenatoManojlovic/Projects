package aplikacija;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JSeparator;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SwingConstants;
import java.awt.Color;

public class Prozor1 extends JFrame {

	private JPanel contentPane;
	private JTable tablica;
	private JTextField ime;
	private JTextField cijena;
	private JTextField dvorana;
	private JTextField datum;
	private JTextField vrijeme;
	JTextField bs;
	JTextField red;
	JTextField part;
	JTextField film;
	JTextField dv;
	JTextField dat;
	JTextField vri;
	DefaultTableModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Prozor1 frame = new Prozor1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	
	}

	/**
	 * Create the frame.
	 */
	public Prozor1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 891, 572);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(253, 234, 219));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(337, 64, 507, 166);
		contentPane.add(scrollPane);
		
		JLabel lblNewLabel = new JLabel("Ime filma: ");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setBounds(10, 72, 63, 20);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Cijena:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(10, 118, 63, 20);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Dvorana: ");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2.setBounds(10, 163, 63, 20);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Datum:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_3.setBounds(10, 210, 63, 20);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Vrijeme:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_4.setBounds(149, 210, 63, 20);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("DOBRODOŠLI!");
		lblNewLabel_5.setBackground(new Color(255, 0, 0));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_5.setBounds(85, 7, 274, 42);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("KINO VELERI");
		lblNewLabel_6.setBackground(new Color(255, 0, 0));
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 21));
		lblNewLabel_6.setBounds(509, 14, 240, 28);
		contentPane.add(lblNewLabel_6);
		
		ime = new JTextField();
		ime.setBounds(83, 73, 118, 20);
		contentPane.add(ime);
		ime.setColumns(10);
		
		cijena = new JTextField();
		cijena.setBounds(83, 119, 31, 20);
		contentPane.add(cijena);
		cijena.setColumns(10);
		
		dvorana = new JTextField();
		dvorana.setBounds(83, 164, 31, 20);
		contentPane.add(dvorana);
		dvorana.setColumns(10);
		
		datum = new JTextField();
		datum.setBounds(53, 210, 86, 20);
		contentPane.add(datum);
		datum.setColumns(10);
		
		vrijeme = new JTextField();
		vrijeme.setBounds(202, 210, 86, 20);
		contentPane.add(vrijeme);
		vrijeme.setColumns(10);
		
		tablica = new JTable();
		tablica.setBounds(326, 53, 518, 198);
		
		scrollPane.setViewportView(tablica);
		model=new DefaultTableModel();
		Object[] column= {"Ime", "Cijena", "Dvorana", "Datum", "Vrijeme"};
		Object[] row= new Object[5];
	    model.setColumnIdentifiers(column);
		tablica.setModel(model);
		tablica.setDefaultEditor(Object.class, null);
		
		JButton btnNewButton = new JButton("Odabir filma");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 int i=tablica.getSelectedRow();
					
				 if (i>=0)
					{
						if (ime.getText().equals("") ||  cijena.getText().equals("") || dvorana.getText().equals("") || datum.getText().equals("") || vrijeme.getText().equals(""))
						{
							ime.setText((String) model.getValueAt(i, 0));
							cijena.setText((String) model.getValueAt(i, 1));
							dvorana.setText((String) model.getValueAt(i, 2));
							datum.setText((String) model.getValueAt(i, 3));
							vrijeme.setText((String) model.getValueAt(i, 4));
						}
						else
							
						{
						
					
						
						}
						film.setText(ime.getText());
						dv.setText(dvorana.getText());
						dat.setText(datum.getText());
						vri.setText(vrijeme.getText());
						JOptionPane.showMessageDialog(null,"Film odabran!");
					}
				 
				
		

				
			}
		});
		btnNewButton.setBounds(74, 241, 187, 34);
		contentPane.add(btnNewButton);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 286, 855, 236);
		contentPane.add(separator);
		
		JLabel lblNewLabel_7 = new JLabel("Odabir sjedala");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_7.setBounds(85, 301, 145, 28);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Broj:");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_8.setBounds(27, 347, 46, 20);
		contentPane.add(lblNewLabel_8);
		
		JComboBox brojevi = new JComboBox();
		brojevi.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		brojevi.setBounds(60, 347, 46, 22);
		contentPane.add(brojevi);
		
		JLabel lblNewLabel_9 = new JLabel("Red:");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_9.setBounds(116, 350, 46, 14);
		contentPane.add(lblNewLabel_9);
		
		JComboBox redovi = new JComboBox();
		redovi.setModel(new DefaultComboBoxModel(new String[] {"A", "B", "C", "D", "E", "F", "G", "H"}));
		redovi.setBounds(149, 347, 46, 22);
		contentPane.add(redovi);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setOrientation(SwingConstants.VERTICAL);
		separator_1.setBounds(337, 286, 528, 236);
		contentPane.add(separator_1);
		
		JLabel lblNewLabel_10 = new JLabel("Parter:");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_10.setBounds(204, 350, 46, 14);
		contentPane.add(lblNewLabel_10);
		
		JComboBox parteri = new JComboBox();
		parteri.setModel(new DefaultComboBoxModel(new String[] {"Lijevo\t", "Desno", "Sredina"}));
		parteri.setBounds(247, 347, 80, 22);
		contentPane.add(parteri);
		
		JButton btnNewButton_1 = new JButton("U redu");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String brojevis=brojevi.getSelectedItem().toString();
				String redovis=redovi.getSelectedItem().toString();
				String parteris=parteri.getSelectedItem().toString();
			if(brojevis=="1") {
				bs.setText(brojevis);
				
				
			}
			else if(brojevis=="2"){
				bs.setText(brojevis);
				
			}
			else if(brojevis=="3"){
				bs.setText(brojevis);
				
			}
			else if(brojevis=="4"){
				bs.setText(brojevis);
				
			}
			else if(brojevis=="5"){
				bs.setText(brojevis);
				
			}
			else if(brojevis=="6"){
				bs.setText(brojevis);
				
			}
			else if(brojevis=="7"){
				bs.setText(brojevis);
				
			}
			else if(brojevis=="8"){
				bs.setText(brojevis);
				
			}
			else if(brojevis=="9"){
				bs.setText(brojevis);
				
			}
			else {
				bs.setText(brojevis);
			}							
			
			if(redovis=="A") {
				red.setText(redovis);
			
			}
			else if(redovis=="B"){
				red.setText(redovis);
				
			}
			else if(redovis=="C"){
				red.setText(redovis);
				
			}
			else if(redovis=="D"){
				red.setText(redovis);
				
			}
			else if(redovis=="E"){
				red.setText(redovis);
				
			}
			else if(redovis=="F"){
				red.setText(redovis);
				
			}
			else if(redovis=="G"){
				red.setText(redovis);
				
			}
			else {
				red.setText(redovis);
			}
			if(parteris=="Lijevo") {
				part.setText(parteris);
			}
			else if(parteris=="Desno") {
				part.setText(parteris);
			}
			else {
				part.setText(parteris);
			}
				JOptionPane.showMessageDialog(null, "Sjedala odabrana!");
			}
			
		});
		btnNewButton_1.setBounds(112, 456, 100, 34);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_12 = new JLabel("Detalji kupnje");
		lblNewLabel_12.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_12.setBounds(551, 304, 145, 23);
		contentPane.add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("Broj sjedala: ");
		lblNewLabel_13.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_13.setBounds(364, 347, 97, 20);
		contentPane.add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("Film:");
		lblNewLabel_14.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_14.setBounds(364, 390, 46, 14);
		contentPane.add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("Dvorana:");
		lblNewLabel_15.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_15.setBounds(364, 429, 63, 14);
		contentPane.add(lblNewLabel_15);
		
		JLabel lblNewLabel_16 = new JLabel("Datum:");
		lblNewLabel_16.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_16.setBounds(364, 471, 46, 14);
		contentPane.add(lblNewLabel_16);
		
		bs = new JTextField();
		bs.setBounds(443, 348, 26, 20);
		contentPane.add(bs);
		bs.setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("Red:");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_11.setBounds(484, 351, 46, 14);
		contentPane.add(lblNewLabel_11);
		
		red = new JTextField();
		red.setBounds(516, 348, 26, 20);
		contentPane.add(red);
		red.setColumns(10);
		
		JLabel lblNewLabel_17 = new JLabel("Parter:");
		lblNewLabel_17.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_17.setBounds(564, 350, 46, 14);
		contentPane.add(lblNewLabel_17);
		
		part = new JTextField();
		part.setBounds(610, 348, 56, 20);
		contentPane.add(part);
		part.setColumns(10);
		
		film = new JTextField();
		film.setBounds(405, 388, 86, 20);
		contentPane.add(film);
		film.setColumns(10);
		
		dv = new JTextField();
		dv.setBounds(425, 427, 26, 20);
		contentPane.add(dv);
		dv.setColumns(10);
		
		dat = new JTextField();
		dat.setBounds(421, 468, 86, 20);
		contentPane.add(dat);
		dat.setColumns(10);
		
		JLabel lblNewLabel_18 = new JLabel("Vrijeme: ");
		lblNewLabel_18.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_18.setBounds(551, 471, 72, 14);
		contentPane.add(lblNewLabel_18);
		
		vri = new JTextField();
		vri.setBounds(610, 468, 86, 20);
		contentPane.add(vri);
		vri.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Potvrdi");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String reds=red.getText();
				String parts=part.getText();
				String films=film.getText();
				String dvs=dv.getText();
				String dats=dat.getText();
				String vris=vri.getText();
				String brojs= bs.getText();
				
				
				try
				 {

				 Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr/rmanojlovic?serverTimezone=UTC", "rmanojlovic", "11");
				
                String upit1="INSERT INTO Karte (BSjedalo,RSjedalo,PSjedalo, Film, Dvorana, Datum, Vrijeme) VALUES (?,?, ?, ?, ?, ?,?)";
				PreparedStatement
				ps1=con.prepareStatement(upit1);
			
				
				 ps1.setString(1, brojs);

				

				 ps1.setString(2, reds);

				 ps1.setString(3, parts);

				 ps1.setString(4, films);

				 ps1.setString(5, dvs);
				 ps1.setString(6, dats);
				 ps1.setString(7, vris);
				 ps1.execute();

					
				ZvarsniProzor zp = new ZvarsniProzor();
				zp.bsj.setText(brojs);
				zp.rd.setText(reds);
				zp.par.setText(parts);
				zp.fm.setText(films);
				zp.dvo.setText(dvs);
				zp.datu.setText(dats);
				zp.vr.setText(vris);
				zp.setVisible(true);
				dispose();
				
			}
			
			 catch(Exception e1)
			 {
			 JOptionPane.showMessageDialog(null, e1);
			 } 
				
				
				
				
				
			
			}
		});
		btnNewButton_2.setBounds(744, 456, 121, 34);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Prikaz filmova");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				 {
				 Class.forName("com.mysql.cj.jdbc.Driver");
				 Connection con=DriverManager.getConnection("jdbc:mysql://student.veleri.hr:/rmanojlovic?serverTimezone=UTC", "rmanojlovic", "11");
				

				 Statement stmt=con.createStatement();
				 String upit="SELECT * from Filmovi";

				 ResultSet rs=stmt.executeQuery(upit);
				 DefaultTableModel model = (DefaultTableModel)tablica.getModel();
               String imes,cijenas,dvoranas,datums,vrijemes;
				 while(rs.next())
				 {

				 imes=rs.getString(1);
				 
                 cijenas=rs.getString(2);
				 dvoranas=rs.getString(3);
				 datums=rs.getString(4);
				 vrijemes=rs.getString(5);
				 String [] row = {imes,cijenas,dvoranas,datums,vrijemes };
				 model.addRow(row);

				 }
			}
				catch (Exception e2)
				 {
				 System.out.println(e2);
				  }
			}
		
		});
		btnNewButton_3.setBounds(337, 241, 187, 34);
		contentPane.add(btnNewButton_3);
		
		JLabel lblNewLabel_19 = new JLabel("€");
		lblNewLabel_19.setBounds(116, 122, 31, 14);
		contentPane.add(lblNewLabel_19);
	}
}
